Rude Breaker 30th AE - Mac (Universal: Apple Silicon + Intel) - version 0.10.1

Requires macOS 10.13 or later (Intel) or macOS 11 or later (Apple Silicon).
The app is ad-hoc signed only (not notarized), so Gatekeeper will block
it the first time. Either:

  1) Right-click (or Control-click) "Rude Breaker.app" > Open > Open, or
  2) In Terminal, in this folder:
       xattr -dr com.apple.quarantine "Rude Breaker.app"
     then double-click it.

Move the folder out of Downloads (e.g. to Desktop or Applications)
before the first launch, so the settings (rudebreaker.cfg) and ranking
(RBRANK.DAT) can be saved inside the app.

SDL2 is inside the app (Contents/Frameworks). Put SGM1.DAT, FPLAY.COM and SONG.DAT
from your own disk in "Rude Breaker.app/Contents/Resources" (right-click >
Show Package Contents). Manuals: MANUAL*.txt.
